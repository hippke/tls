Installation
=====================================

TLS can be installed conveniently using pip::

    pip install tls-package

The latest version can be pulled from github::

    git clone https://github.com/hippke/tls.git
    cd tls
    python3 setup.py install