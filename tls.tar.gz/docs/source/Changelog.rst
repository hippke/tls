Changelog
=========

This describes changes to TLS.


Version 1.0 (01 January 2018)
------------------------------

Initial release for the paper.